/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mlbaseball;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.FileInputStream;
import java.nio.file.Paths;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.xml.bind.JAXB;
import javax.xml.bind.annotation.XmlElement;
/**
 *
 * @author jones
 */
public class BaseballController implements Initializable{
    //ObservableList list = FXCollections.observableArrayList();
    
    @FXML private ListView teamList;
    @FXML private TableView playerTbl;
    @FXML private TableColumn <String, Player> playerCol;
    @FXML private TableColumn <String, Player> avgCol;
    
    private final List<Player> ball = new ArrayList<>();
    
    //private final List<Player> players = new ArrayList<>();
    
    private final List<Player> playersofteam = new ArrayList<>();
    private final String DIR = System.getProperty("user.dir");

    
    
    

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        readFile();
        
        teamList.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>(){
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                         
                playerCol.setCellValueFactory(new PropertyValueFactory<>("Name"));
                avgCol.setCellValueFactory(new PropertyValueFactory<>("BattingAvg"));
                
                ObservableList<Player> result = FXCollections.observableArrayList();
                
                //Bind the list  to the table
                getPlayers(newValue);
                System.out.println(newValue);
                playerTbl.setItems(FXCollections.observableList(playersofteam));   
                
            }

              /**
                * Sequential search of the Teams by name
                * @param 
                * @return 
                */
                    
        });
        
        //ObservableList<String> ballList = FXCollections.observableArrayList();

        
        //Open csv file for input
        

    
        
       
    }
    
    private void getPlayers(String teamname) {
        
            playersofteam.clear();
        for(int i = 0; i < ball.size(); i++){
            if(ball.get(i).getPlayerTeam().equals(teamname)){
                playersofteam.add(new Player(ball.get(i).getPlayerName(),ball.get(i).getPlayerTeam(),ball.get(i).getAvg(),ball.get(i).getHits()));
              
            }
        }   
    }
    
    
    private void readFile() {
       
        //ObservableList to add states to the ListView
        ObservableList<String> ballList = FXCollections.observableArrayList();
        
        //Open csv file for input
        try(BufferedReader csvReader = Files.newBufferedReader(Paths.get( DIR + "/src/mlbaseball/data/baseball.xml"))){
            
                Reader ball2 = JAXB.unmarshal(csvReader, Reader.class);
               
                for(Player baseballRead1 : ball2.getbaseballClass())
                {
                    //add object to ArrayList
                    ball.add(baseballRead1);
                    //add player name to ObservableList
                    if(!ballList.contains(baseballRead1.getPlayerTeam()))
                    {
                        ballList.add(baseballRead1.getPlayerTeam());                      
                    }
                    
                }
                          
    }catch(IOException e){
        System.err.println("Error opening file");
        e.printStackTrace();   
    }
        
        
        Collections.sort(ball, new baseballComparator());
        Collections.sort(ballList);
        
        teamList.setItems(ballList);
        playerTbl.setItems(ballList);
    }
    
}
