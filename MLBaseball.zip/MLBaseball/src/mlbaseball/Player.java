/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mlbaseball;

/**
 *
 * @author jones
 */
public class Player {
    
    private String playerName, playerTeam;
    private int atBats, hits;
    private float batAvg;
    
    public Player() {
    }

    public Player(String playerName, String playerTeam, int atBats, int hits, float batAvg, String teamName) {
        this.playerName = playerName;
        this.playerTeam = playerTeam;
        this.atBats = atBats;
        this.hits = hits;
        this.batAvg = batAvg;
    }

    Player(String playerName, String playerTeam, float avg, int hits) {
        this.playerName = playerName;
        this.playerTeam = playerTeam;
        this.atBats = atBats;
        this.hits = hits;
        this.batAvg = hits/atBats;
        
    }
    
    @Override
    public String toString(){
        return "Player{" + "Name=" + playerName + "Team=" + playerTeam;
    }
    
    public float getAvg(){
        return Math.round(batAvg);
    }
    
    public void setAvg(int atBats, int hits){
        this.batAvg = (hits/atBats);
    }
    
    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public String getPlayerTeam() {
        return playerTeam;
    }

    public void setPlayerTeam(String playerTeam) {
        this.playerTeam = playerTeam;
    }

    public int getAtBats() {
        return atBats;
    }

    public void setAtBats(int atBats) {
        this.atBats = atBats;
    }

    public int getHits() {
        return hits;
    }

    public void setHits(int hits) {
        this.hits = hits;
    }
    
    
    
    
}
